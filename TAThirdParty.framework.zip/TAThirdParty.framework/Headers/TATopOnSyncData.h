//
//  TATopOnSyncData.h
//  ThinkingSDK
//
//  Created by wwango on 2022/3/25.
//

#import "TABaseSyncData.h"

NS_ASSUME_NONNULL_BEGIN

@interface TATopOnSyncData : TABaseSyncData

@end

NS_ASSUME_NONNULL_END
