//
//  TAThirdParty.h
//  TAThirdParty
//
//  Created by Charles on 9.1.23.
//

#import <Foundation/Foundation.h>

//! Project version number for TAThirdParty.
FOUNDATION_EXPORT double TAThirdPartyVersionNumber;

//! Project version string for TAThirdParty.
FOUNDATION_EXPORT const unsigned char TAThirdPartyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TAThirdParty/PublicHeader.h>


